# Messaging Domain Blueprints

Technical implementation blueprints for the Messaging domain.

## Blueprints

- [Real-Time Chat](./real-time-chat.md) - WebSocket-based real-time messaging, context-aware chat threads, and immutable message history

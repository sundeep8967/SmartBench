# Fulfillment Domain Blueprints

Technical implementation blueprints for the Fulfillment domain.

## Blueprints

- [Time Tracking Verification](./time-tracking-verification.md) - Time tracking and verification system with Negotiation Loop, offline support, and Visual Verify offline protocol
